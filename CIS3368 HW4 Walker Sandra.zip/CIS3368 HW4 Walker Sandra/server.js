// server.js
//Sandra Walker
//1991144
//Tutoring from tutor
//W3 schools

var express = require('express');
var path = require('path');
var routes = require('./routes/index');

var app = express();
// app.get('/', (req, res) => {
//   res.render('index');  
// });

// Set up the view engine (EJS).
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Middleware
app.use(require('morgan')('combined'));
app.use(require('cookie-parser')());
app.use(require('body-parser').urlencoded({ extended: true }));

// Serve static files from the 'public' directory.
app.use(express.static(path.join(__dirname, 'resources')));

// Routes
app.use('/', routes);

// Start the server
const port_running = 3000;
app.listen(port_running, () => {
  console.log("Application running at: http://localhost:" + port_running);
});
