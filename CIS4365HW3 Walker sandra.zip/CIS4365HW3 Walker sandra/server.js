//sandra walker
//1991144
//professor template
// tutor


// Load the things we need
var express = require('express');
var app = express();
const bodyParser = require('body-parser');
const axios = require('axios');
const path = require('path');

app.use(bodyParser.urlencoded({ extended: true }));

// Set the view engine to ejs
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));// to acces the path for clothing

// from the view floder which have page folder in itthen index.ejs
app.get('/', async (req, res) => {
    try {
        const response = await axios.get('https://fakestoreapi.com/products');
        const products = response.data.sort((a, b) => a.id - b.id); // Sort by id in ascending order
        const firstThreeProducts = products.slice(0, 3); // show only three products per page
        res.render('pages/index', { products: firstThreeProducts });
    } catch (error) {
        console.error("Error fetching products:", error);
        res.render('pages/index', { products: [] });
    }
});

// Endpoint to load random products
app.post('/load', async (req, res) => {
    try {
        const response = await axios.get('https://fakestoreapi.com/products');
        const products = response.data.sort((a, b) => a.id - b.id); // Sort by id in ascending order
        const firstThreeProducts = products.slice(0, 3); // Get the first three products
        res.render('pages/index', { products: firstThreeProducts });
    } catch (error) {
        console.error(error);
        res.render('pages/index', { products: [] }); //catch is to catch a block of code, if error occur it will block the error
    }
});

app.listen(8080, () => {
    console.log('8080 is the magic port');//listing to port
});
